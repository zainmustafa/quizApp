/**
 * Created by taimoor on 6/4/2015.
 */

    function Questions(message, option1, option2, option3, option4, answer){
        this.message = message;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.answer = answer;
    }
    var quesiton1 = new Questions("What is your name ?","ZA", "TA", "AW", "NA", "AW");
    var question2 = new Questions("What is your age ?", 1, 2, 3, 4, 4);
    var question3 = new Questions("What is your city ?","Khi", "Isb", "Rwl", "Lhr", "Lhr");

    var arr = [quesiton1, question2, question3];
    var i = 0;


var app = angular.module('radioDemo1', ['ngMaterial']);

    app.controller('AppCtrl', function($scope) {
        $scope.data = {

        };
        $scope.ques = {
            messageName: arr[i].message
        };

        $scope.radioData = [
            { label: arr[i].option1, value: arr[i].option1 },
            { label: arr[i].option2, value: arr[i].option2 },
            { label: arr[i].option3, value: arr[i].option3 },
            { label: arr[i].option4, value: arr[i].option4 }
        ];
        $scope.nextItem = function() {
            if($scope.data === arr[i].answer){
                alert("BullsEye");
                i++;
                $scope.ques = {
                    messageName: arr[i].message
                };
                $scope.radioData = [
                    { label: arr[i].option1, value: arr[i].option1 },
                    { label: arr[i].option2, value: arr[i].option2 },
                    { label: arr[i].option3, value: arr[i].option3 },
                    { label: arr[i].option4, value: arr[i].option4 }
                ];
            }
        };

    });

